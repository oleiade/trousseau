_trousseau() {
    local i cur prev opts cmd
    COMPREPLY=()
    if [[ "${BASH_VERSINFO[0]}" -ge 4 ]]; then
        cur="$2"
    else
        cur="${COMP_WORDS[COMP_CWORD]}"
    fi
    prev="$3"
    cmd=""
    opts=""

    for i in "${COMP_WORDS[@]:0:COMP_CWORD}"
    do
        case "${cmd},${i}" in
            ",$1")
                cmd="trousseau"
                ;;
            trousseau,__clip-clear)
                cmd="trousseau__subcmd____clip__subcmd__clear"
                ;;
            trousseau,completions)
                cmd="trousseau__subcmd__completions"
                ;;
            trousseau,edit)
                cmd="trousseau__subcmd__edit"
                ;;
            trousseau,env)
                cmd="trousseau__subcmd__env"
                ;;
            trousseau,export)
                cmd="trousseau__subcmd__export"
                ;;
            trousseau,get)
                cmd="trousseau__subcmd__get"
                ;;
            trousseau,help)
                cmd="trousseau__subcmd__help"
                ;;
            trousseau,import)
                cmd="trousseau__subcmd__import"
                ;;
            trousseau,info)
                cmd="trousseau__subcmd__info"
                ;;
            trousseau,init)
                cmd="trousseau__subcmd__init"
                ;;
            trousseau,ls)
                cmd="trousseau__subcmd__ls"
                ;;
            trousseau,man)
                cmd="trousseau__subcmd__man"
                ;;
            trousseau,migrate)
                cmd="trousseau__subcmd__migrate"
                ;;
            trousseau,mv)
                cmd="trousseau__subcmd__mv"
                ;;
            trousseau,recipients)
                cmd="trousseau__subcmd__recipients"
                ;;
            trousseau,rekey)
                cmd="trousseau__subcmd__rekey"
                ;;
            trousseau,rm)
                cmd="trousseau__subcmd__rm"
                ;;
            trousseau,run)
                cmd="trousseau__subcmd__run"
                ;;
            trousseau,set)
                cmd="trousseau__subcmd__set"
                ;;
            trousseau__subcmd__help,__clip-clear)
                cmd="trousseau__subcmd__help__subcmd____clip__subcmd__clear"
                ;;
            trousseau__subcmd__help,completions)
                cmd="trousseau__subcmd__help__subcmd__completions"
                ;;
            trousseau__subcmd__help,edit)
                cmd="trousseau__subcmd__help__subcmd__edit"
                ;;
            trousseau__subcmd__help,env)
                cmd="trousseau__subcmd__help__subcmd__env"
                ;;
            trousseau__subcmd__help,export)
                cmd="trousseau__subcmd__help__subcmd__export"
                ;;
            trousseau__subcmd__help,get)
                cmd="trousseau__subcmd__help__subcmd__get"
                ;;
            trousseau__subcmd__help,help)
                cmd="trousseau__subcmd__help__subcmd__help"
                ;;
            trousseau__subcmd__help,import)
                cmd="trousseau__subcmd__help__subcmd__import"
                ;;
            trousseau__subcmd__help,info)
                cmd="trousseau__subcmd__help__subcmd__info"
                ;;
            trousseau__subcmd__help,init)
                cmd="trousseau__subcmd__help__subcmd__init"
                ;;
            trousseau__subcmd__help,ls)
                cmd="trousseau__subcmd__help__subcmd__ls"
                ;;
            trousseau__subcmd__help,man)
                cmd="trousseau__subcmd__help__subcmd__man"
                ;;
            trousseau__subcmd__help,migrate)
                cmd="trousseau__subcmd__help__subcmd__migrate"
                ;;
            trousseau__subcmd__help,mv)
                cmd="trousseau__subcmd__help__subcmd__mv"
                ;;
            trousseau__subcmd__help,recipients)
                cmd="trousseau__subcmd__help__subcmd__recipients"
                ;;
            trousseau__subcmd__help,rekey)
                cmd="trousseau__subcmd__help__subcmd__rekey"
                ;;
            trousseau__subcmd__help,rm)
                cmd="trousseau__subcmd__help__subcmd__rm"
                ;;
            trousseau__subcmd__help,run)
                cmd="trousseau__subcmd__help__subcmd__run"
                ;;
            trousseau__subcmd__help,set)
                cmd="trousseau__subcmd__help__subcmd__set"
                ;;
            trousseau__subcmd__help__subcmd__recipients,add)
                cmd="trousseau__subcmd__help__subcmd__recipients__subcmd__add"
                ;;
            trousseau__subcmd__help__subcmd__recipients,ls)
                cmd="trousseau__subcmd__help__subcmd__recipients__subcmd__ls"
                ;;
            trousseau__subcmd__help__subcmd__recipients,rm)
                cmd="trousseau__subcmd__help__subcmd__recipients__subcmd__rm"
                ;;
            trousseau__subcmd__recipients,add)
                cmd="trousseau__subcmd__recipients__subcmd__add"
                ;;
            trousseau__subcmd__recipients,help)
                cmd="trousseau__subcmd__recipients__subcmd__help"
                ;;
            trousseau__subcmd__recipients,ls)
                cmd="trousseau__subcmd__recipients__subcmd__ls"
                ;;
            trousseau__subcmd__recipients,rm)
                cmd="trousseau__subcmd__recipients__subcmd__rm"
                ;;
            trousseau__subcmd__recipients__subcmd__help,add)
                cmd="trousseau__subcmd__recipients__subcmd__help__subcmd__add"
                ;;
            trousseau__subcmd__recipients__subcmd__help,help)
                cmd="trousseau__subcmd__recipients__subcmd__help__subcmd__help"
                ;;
            trousseau__subcmd__recipients__subcmd__help,ls)
                cmd="trousseau__subcmd__recipients__subcmd__help__subcmd__ls"
                ;;
            trousseau__subcmd__recipients__subcmd__help,rm)
                cmd="trousseau__subcmd__recipients__subcmd__help__subcmd__rm"
                ;;
            *)
                ;;
        esac
    done

    case "${cmd}" in
        trousseau)
            opts="-h -V --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help --version init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 1 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd____clip__subcmd__clear)
            opts="-h --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__completions)
            opts="-h --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help bash elvish fish powershell zsh"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__edit)
            opts="-h --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__env)
            opts="-h --format --env-prefix --only --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --format)
                    COMPREPLY=($(compgen -W "shell dotenv json" -- "${cur}"))
                    return 0
                    ;;
                --env-prefix)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --only)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__export)
            opts="-h --format --out --force --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --format)
                    COMPREPLY=($(compgen -W "json dotenv toml" -- "${cur}"))
                    return 0
                    ;;
                --out)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__get)
            opts="-h --out --force --clip --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --out)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help)
            opts="init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd____clip__subcmd__clear)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__completions)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__edit)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__env)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__export)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__get)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__import)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__info)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__init)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__ls)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__man)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__migrate)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__mv)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__recipients)
            opts="ls add rm"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__recipients__subcmd__add)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__recipients__subcmd__ls)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__recipients__subcmd__rm)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__rekey)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__rm)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__run)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__help__subcmd__set)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__import)
            opts="-h --format --strategy --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --format)
                    COMPREPLY=($(compgen -W "json dotenv toml" -- "${cur}"))
                    return 0
                    ;;
                --strategy)
                    COMPREPLY=($(compgen -W "keep overwrite fail" -- "${cur}"))
                    return 0
                    ;;
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__info)
            opts="-h --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__init)
            opts="-h --recipient --recipients-file --passphrase --no-self --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --recipient)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --recipients-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__ls)
            opts="-h --long --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__man)
            opts="-h --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__migrate)
            opts="-h --gpg --gnupg-home --new-passphrase-file --recipient --recipients-file --passphrase --no-self --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --gpg)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --gnupg-home)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --new-passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --recipient)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --recipients-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__mv)
            opts="-h --force --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__recipients)
            opts="-h --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help ls add rm help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__recipients__subcmd__add)
            opts="-h --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__recipients__subcmd__help)
            opts="ls add rm help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__recipients__subcmd__help__subcmd__add)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__recipients__subcmd__help__subcmd__help)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__recipients__subcmd__help__subcmd__ls)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__recipients__subcmd__help__subcmd__rm)
            opts=""
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 4 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__recipients__subcmd__ls)
            opts="-h --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__recipients__subcmd__rm)
            opts="-h --force --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 3 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__rekey)
            opts="-h --to-passphrase --to-recipients --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --to-recipients)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__rm)
            opts="-h --force --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__run)
            opts="-h --env-prefix --only --no-inherit --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --env-prefix)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --only)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
        trousseau__subcmd__set)
            opts="-h --from-file --from-env --binary --env --description --store --global --identity --identity-file --passphrase-file --json --quiet --no-input --help"
            if [[ ${cur} == -* || ${COMP_CWORD} -eq 2 ]] ; then
                COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
                return 0
            fi
            case "${prev}" in
                --from-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --from-env)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --env)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --description)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --store)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --identity-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                --passphrase-file)
                    COMPREPLY=($(compgen -f "${cur}"))
                    return 0
                    ;;
                *)
                    COMPREPLY=()
                    ;;
            esac
            COMPREPLY=( $(compgen -W "${opts}" -- "${cur}") )
            return 0
            ;;
    esac
}

if [[ "${BASH_VERSINFO[0]}" -eq 4 && "${BASH_VERSINFO[1]}" -ge 4 || "${BASH_VERSINFO[0]}" -gt 4 ]]; then
    complete -F _trousseau -o nosort -o bashdefault -o default trousseau
else
    complete -F _trousseau -o bashdefault -o default trousseau
fi
