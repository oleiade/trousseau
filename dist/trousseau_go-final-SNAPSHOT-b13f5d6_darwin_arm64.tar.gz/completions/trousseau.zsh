#compdef trousseau

autoload -U is-at-least

_trousseau() {
    typeset -A opt_args
    typeset -a _arguments_options
    local ret=1

    if is-at-least 5.2; then
        _arguments_options=(-s -S -C)
    else
        _arguments_options=(-s -C)
    fi

    local context curcontext="$curcontext" state line
    _arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
'-V[Print version]' \
'--version[Print version]' \
":: :_trousseau_commands" \
"*::: :->trousseau" \
&& ret=0
    case $state in
    (trousseau)
        words=($line[1] "${words[@]}")
        (( CURRENT += 1 ))
        curcontext="${curcontext%:*:*}:trousseau-command-$line[1]:"
        case $line[1] in
            (init)
_arguments "${_arguments_options[@]}" : \
'*--recipient=[A recipient to encrypt to. Repeatable]:R:_default' \
'--recipients-file=[A file of recipients, one per line (blank lines and \`#\` comments ignored)]:PATH:_files' \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'(--recipient --recipients-file --no-self)--passphrase[Create a passphrase store instead of a recipients store]' \
'--no-self[Do not add the caller'\''s own recipient to a recipients store]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(info)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(set)
_arguments "${_arguments_options[@]}" : \
'(--from-env)--from-file=[Read the value from this file. \`-\` means stdin, verbatim]:PATH:_files' \
'--from-env=[Read the value from this environment variable]:NAME:_default' \
'--env=[Override the derived environment variable name]:NAME:_default' \
'--description=[A free-text description of the entry]:TEXT:_default' \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--binary[Force base64 encoding even if the value is valid UTF-8]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
':key -- The key to set:_default' \
&& ret=0
;;
(get)
_arguments "${_arguments_options[@]}" : \
'--out=[Write the value to this file instead of stdout]:PATH:_files' \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--force[Overwrite \`--out\` if it already exists]' \
'--clip[Copy the value to the clipboard instead of printing it]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
':key -- The key to read:_default' \
&& ret=0
;;
(ls)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--long[Print a table with encoding, env name, update time, and description columns. Never values]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
'::prefix -- Only list keys equal to, or nested under, this path prefix:_default' \
&& ret=0
;;
(rm)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--force[Ignore keys that do not exist instead of failing]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
'*::keys -- The keys to remove:_default' \
&& ret=0
;;
(mv)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--force[Overwrite \`new\` if it already exists]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
':old -- The existing key:_default' \
':new -- The new key:_default' \
&& ret=0
;;
(recipients)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
":: :_trousseau__subcmd__recipients_commands" \
"*::: :->recipients" \
&& ret=0

    case $state in
    (recipients)
        words=($line[1] "${words[@]}")
        (( CURRENT += 1 ))
        curcontext="${curcontext%:*:*}:trousseau-recipients-command-$line[1]:"
        case $line[1] in
            (ls)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(add)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
'*::recipients -- The recipients to add:_default' \
&& ret=0
;;
(rm)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--force[Skip the "you removed your own recipient" confirmation]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
'*::recipients -- The recipients to remove:_default' \
&& ret=0
;;
(help)
_arguments "${_arguments_options[@]}" : \
":: :_trousseau__subcmd__recipients__subcmd__help_commands" \
"*::: :->help" \
&& ret=0

    case $state in
    (help)
        words=($line[1] "${words[@]}")
        (( CURRENT += 1 ))
        curcontext="${curcontext%:*:*}:trousseau-recipients-help-command-$line[1]:"
        case $line[1] in
            (ls)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(add)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(rm)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(help)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
        esac
    ;;
esac
;;
        esac
    ;;
esac
;;
(rekey)
_arguments "${_arguments_options[@]}" : \
'*--to-recipients=[Convert to a recipients store with exactly these recipients]:R:_default' \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'(--to-recipients)--to-passphrase[Convert to a passphrase store]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(export)
_arguments "${_arguments_options[@]}" : \
'--format=[The output format]:FORMAT:((json\:"The full JSON payload document"
dotenv\:"One \`NAME="value"\` line per UTF-8 entry"
toml\:"The \`edit\` TOML document format"))' \
'--out=[Write to this file instead of stdout]:PATH:_files' \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--force[Overwrite \`--out\` if it already exists]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help (see more with '\''--help'\'')]' \
'--help[Print help (see more with '\''--help'\'')]' \
&& ret=0
;;
(import)
_arguments "${_arguments_options[@]}" : \
'--format=[The input format]:FORMAT:((json\:"The full JSON payload document"
dotenv\:"One \`NAME="value"\` line per UTF-8 entry"
toml\:"The \`edit\` TOML document format"))' \
'--strategy=[How to resolve a key that already exists]:STRATEGY:((keep\:"Keep the existing entry"
overwrite\:"Replace the existing entry with the imported one"
fail\:"Abort the whole import on any collision"))' \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help (see more with '\''--help'\'')]' \
'--help[Print help (see more with '\''--help'\'')]' \
'::path -- Read from this file instead of stdin:_files' \
&& ret=0
;;
(run)
_arguments "${_arguments_options[@]}" : \
'--env-prefix=[A prefix prepended to every injected environment variable name. Defaults to \`\[run\].env_prefix\` from the configuration file (3.4) when absent]:P:_default' \
'*--only=[Only inject entries under this path prefix. Repeatable]:KEYPREFIX:_default' \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--no-inherit[Give the child only the injected variables plus a small allow list, instead of inheriting the parent'\''s environment]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
'*::cmd -- The command, and its arguments, to run:_default' \
&& ret=0
;;
(env)
_arguments "${_arguments_options[@]}" : \
'--format=[The output format. \`--json\` is an alias for \`--format json\`]:FORMAT:((shell\:"\`export NAME='\''value'\''\` lines"
dotenv\:"\`NAME="value"\` lines"
json\:"A single \`{"NAME"\: "value"}\` JSON object"))' \
'--env-prefix=[A prefix prepended to every environment variable name. Defaults to \`\[run\].env_prefix\` from the configuration file (3.4) when absent]:P:_default' \
'*--only=[Only include entries under this path prefix. Repeatable]:KEYPREFIX:_default' \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help (see more with '\''--help'\'')]' \
'--help[Print help (see more with '\''--help'\'')]' \
&& ret=0
;;
(edit)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
&& ret=0
;;
(migrate)
_arguments "${_arguments_options[@]}" : \
'--gpg=[The \`gpg\` binary to use for an \`OpenPGP\` legacy store]:PATH:_files' \
'--gnupg-home=[An isolated \`GNUPGHOME\` to use when invoking \`gpg\`]:PATH:_files' \
'--new-passphrase-file=[A file holding the new store'\''s passphrase (only with \`--passphrase\`)]:PATH:_files' \
'*--recipient=[A recipient to encrypt to. Repeatable]:R:_default' \
'--recipients-file=[A file of recipients, one per line (blank lines and \`#\` comments ignored)]:PATH:_files' \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'(--recipient --recipients-file --no-self)--passphrase[Create a passphrase store instead of a recipients store]' \
'--no-self[Do not add the caller'\''s own recipient to a recipients store]' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
':source -- The legacy v0.4 store file to read:_files' \
&& ret=0
;;
(completions)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
':shell -- The shell to generate a completion script for:(bash elvish fish powershell zsh)' \
&& ret=0
;;
(man)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
'::subcommand -- Print the man page for this subcommand instead of the top level:_default' \
&& ret=0
;;
(__clip-clear)
_arguments "${_arguments_options[@]}" : \
'--store=[The store to operate on. Overrides every other resolution rule (3.2)]:PATH:_files' \
'*--identity=[An identity file to try when unlocking a recipients store. Repeatable (3.3.2)]:PATH:_files' \
'--identity-file=[Hidden, single-value counterpart to \`--identity\` populated from \`TROUSSEAU_IDENTITY_FILE\` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by \`context.rs\`]:PATH:_files' \
'--passphrase-file=[A file holding the passphrase for a passphrase store (3.3.3)]:PATH:_files' \
'--global[Use the personal store instead of the nearest project store (3.2)]' \
'--json[Emit machine-readable JSON instead of human-readable text (3.5.1)]' \
'--quiet[Suppress informational stderr lines. Errors still print (3.5.1)]' \
'--no-input[Never prompt. Anything that would have prompted fails instead (3.5.1)]' \
'-h[Print help]' \
'--help[Print help]' \
':hash -- The lowercase hex SHA-256 digest of the value that was copied:_default' \
':seconds -- How many seconds to wait before clearing the clipboard:_default' \
&& ret=0
;;
(help)
_arguments "${_arguments_options[@]}" : \
":: :_trousseau__subcmd__help_commands" \
"*::: :->help" \
&& ret=0

    case $state in
    (help)
        words=($line[1] "${words[@]}")
        (( CURRENT += 1 ))
        curcontext="${curcontext%:*:*}:trousseau-help-command-$line[1]:"
        case $line[1] in
            (init)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(info)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(set)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(get)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(ls)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(rm)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(mv)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(recipients)
_arguments "${_arguments_options[@]}" : \
":: :_trousseau__subcmd__help__subcmd__recipients_commands" \
"*::: :->recipients" \
&& ret=0

    case $state in
    (recipients)
        words=($line[1] "${words[@]}")
        (( CURRENT += 1 ))
        curcontext="${curcontext%:*:*}:trousseau-help-recipients-command-$line[1]:"
        case $line[1] in
            (ls)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(add)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(rm)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
        esac
    ;;
esac
;;
(rekey)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(export)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(import)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(run)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(env)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(edit)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(migrate)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(completions)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(man)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(__clip-clear)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
(help)
_arguments "${_arguments_options[@]}" : \
&& ret=0
;;
        esac
    ;;
esac
;;
        esac
    ;;
esac
}

(( $+functions[_trousseau_commands] )) ||
_trousseau_commands() {
    local commands; commands=(
'init:Create a new store' \
'info:Show information about the resolved store' \
'set:Set a key'\''s value' \
'get:Get a key'\''s value' \
'ls:List keys' \
'rm:Remove one or more keys' \
'mv:Rename a key' \
'recipients:Manage a recipients store'\''s recipient list' \
'rekey:Re-encrypt the store, optionally changing its kind or recipients' \
'export:Export the store'\''s entries' \
'import:Import entries into the store' \
'run:Run a command with the store'\''s entries injected as environment variables' \
'env:Print the store'\''s entries as environment variable assignments' \
'edit:Edit the store in \`\$VISUAL\` or \`\$EDITOR\`' \
'migrate:Migrate a legacy v0.4 store into a new store' \
'completions:Print a shell completion script' \
'man:Print a roff man page' \
'__clip-clear:Clear the clipboard after \`get --clip\` (hidden, internal)' \
'help:Print this message or the help of the given subcommand(s)' \
    )
    _describe -t commands 'trousseau commands' commands "$@"
}
(( $+functions[_trousseau__subcmd____clip-clear_commands] )) ||
_trousseau__subcmd____clip-clear_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau __clip-clear commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__completions_commands] )) ||
_trousseau__subcmd__completions_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau completions commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__edit_commands] )) ||
_trousseau__subcmd__edit_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau edit commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__env_commands] )) ||
_trousseau__subcmd__env_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau env commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__export_commands] )) ||
_trousseau__subcmd__export_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau export commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__get_commands] )) ||
_trousseau__subcmd__get_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau get commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help_commands] )) ||
_trousseau__subcmd__help_commands() {
    local commands; commands=(
'init:Create a new store' \
'info:Show information about the resolved store' \
'set:Set a key'\''s value' \
'get:Get a key'\''s value' \
'ls:List keys' \
'rm:Remove one or more keys' \
'mv:Rename a key' \
'recipients:Manage a recipients store'\''s recipient list' \
'rekey:Re-encrypt the store, optionally changing its kind or recipients' \
'export:Export the store'\''s entries' \
'import:Import entries into the store' \
'run:Run a command with the store'\''s entries injected as environment variables' \
'env:Print the store'\''s entries as environment variable assignments' \
'edit:Edit the store in \`\$VISUAL\` or \`\$EDITOR\`' \
'migrate:Migrate a legacy v0.4 store into a new store' \
'completions:Print a shell completion script' \
'man:Print a roff man page' \
'__clip-clear:Clear the clipboard after \`get --clip\` (hidden, internal)' \
'help:Print this message or the help of the given subcommand(s)' \
    )
    _describe -t commands 'trousseau help commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd____clip-clear_commands] )) ||
_trousseau__subcmd__help__subcmd____clip-clear_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help __clip-clear commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__completions_commands] )) ||
_trousseau__subcmd__help__subcmd__completions_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help completions commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__edit_commands] )) ||
_trousseau__subcmd__help__subcmd__edit_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help edit commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__env_commands] )) ||
_trousseau__subcmd__help__subcmd__env_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help env commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__export_commands] )) ||
_trousseau__subcmd__help__subcmd__export_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help export commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__get_commands] )) ||
_trousseau__subcmd__help__subcmd__get_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help get commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__help_commands] )) ||
_trousseau__subcmd__help__subcmd__help_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help help commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__import_commands] )) ||
_trousseau__subcmd__help__subcmd__import_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help import commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__info_commands] )) ||
_trousseau__subcmd__help__subcmd__info_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help info commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__init_commands] )) ||
_trousseau__subcmd__help__subcmd__init_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help init commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__ls_commands] )) ||
_trousseau__subcmd__help__subcmd__ls_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help ls commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__man_commands] )) ||
_trousseau__subcmd__help__subcmd__man_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help man commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__migrate_commands] )) ||
_trousseau__subcmd__help__subcmd__migrate_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help migrate commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__mv_commands] )) ||
_trousseau__subcmd__help__subcmd__mv_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help mv commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__recipients_commands] )) ||
_trousseau__subcmd__help__subcmd__recipients_commands() {
    local commands; commands=(
'ls:List the store'\''s recipients' \
'add:Add one or more recipients' \
'rm:Remove one or more recipients' \
    )
    _describe -t commands 'trousseau help recipients commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__recipients__subcmd__add_commands] )) ||
_trousseau__subcmd__help__subcmd__recipients__subcmd__add_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help recipients add commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__recipients__subcmd__ls_commands] )) ||
_trousseau__subcmd__help__subcmd__recipients__subcmd__ls_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help recipients ls commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__recipients__subcmd__rm_commands] )) ||
_trousseau__subcmd__help__subcmd__recipients__subcmd__rm_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help recipients rm commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__rekey_commands] )) ||
_trousseau__subcmd__help__subcmd__rekey_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help rekey commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__rm_commands] )) ||
_trousseau__subcmd__help__subcmd__rm_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help rm commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__run_commands] )) ||
_trousseau__subcmd__help__subcmd__run_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help run commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__help__subcmd__set_commands] )) ||
_trousseau__subcmd__help__subcmd__set_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau help set commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__import_commands] )) ||
_trousseau__subcmd__import_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau import commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__info_commands] )) ||
_trousseau__subcmd__info_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau info commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__init_commands] )) ||
_trousseau__subcmd__init_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau init commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__ls_commands] )) ||
_trousseau__subcmd__ls_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau ls commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__man_commands] )) ||
_trousseau__subcmd__man_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau man commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__migrate_commands] )) ||
_trousseau__subcmd__migrate_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau migrate commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__mv_commands] )) ||
_trousseau__subcmd__mv_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau mv commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__recipients_commands] )) ||
_trousseau__subcmd__recipients_commands() {
    local commands; commands=(
'ls:List the store'\''s recipients' \
'add:Add one or more recipients' \
'rm:Remove one or more recipients' \
'help:Print this message or the help of the given subcommand(s)' \
    )
    _describe -t commands 'trousseau recipients commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__recipients__subcmd__add_commands] )) ||
_trousseau__subcmd__recipients__subcmd__add_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau recipients add commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__recipients__subcmd__help_commands] )) ||
_trousseau__subcmd__recipients__subcmd__help_commands() {
    local commands; commands=(
'ls:List the store'\''s recipients' \
'add:Add one or more recipients' \
'rm:Remove one or more recipients' \
'help:Print this message or the help of the given subcommand(s)' \
    )
    _describe -t commands 'trousseau recipients help commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__recipients__subcmd__help__subcmd__add_commands] )) ||
_trousseau__subcmd__recipients__subcmd__help__subcmd__add_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau recipients help add commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__recipients__subcmd__help__subcmd__help_commands] )) ||
_trousseau__subcmd__recipients__subcmd__help__subcmd__help_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau recipients help help commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__recipients__subcmd__help__subcmd__ls_commands] )) ||
_trousseau__subcmd__recipients__subcmd__help__subcmd__ls_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau recipients help ls commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__recipients__subcmd__help__subcmd__rm_commands] )) ||
_trousseau__subcmd__recipients__subcmd__help__subcmd__rm_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau recipients help rm commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__recipients__subcmd__ls_commands] )) ||
_trousseau__subcmd__recipients__subcmd__ls_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau recipients ls commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__recipients__subcmd__rm_commands] )) ||
_trousseau__subcmd__recipients__subcmd__rm_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau recipients rm commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__rekey_commands] )) ||
_trousseau__subcmd__rekey_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau rekey commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__rm_commands] )) ||
_trousseau__subcmd__rm_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau rm commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__run_commands] )) ||
_trousseau__subcmd__run_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau run commands' commands "$@"
}
(( $+functions[_trousseau__subcmd__set_commands] )) ||
_trousseau__subcmd__set_commands() {
    local commands; commands=()
    _describe -t commands 'trousseau set commands' commands "$@"
}

if [ "$funcstack[1]" = "_trousseau" ]; then
    _trousseau "$@"
else
    compdef _trousseau trousseau
fi
