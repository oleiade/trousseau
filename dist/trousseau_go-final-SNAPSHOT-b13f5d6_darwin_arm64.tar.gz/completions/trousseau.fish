# Print an optspec for argparse to handle cmd's options that are independent of any subcommand.
function __fish_trousseau_global_optspecs
    string join \n store= global identity= identity-file= passphrase-file= json quiet no-input h/help V/version
end

function __fish_trousseau_needs_command
    # Figure out if the current invocation already has a command.
    set -l cmd (commandline -opc)
    set -e cmd[1]
    argparse -s (__fish_trousseau_global_optspecs) -- $cmd 2>/dev/null
    or return
    if set -q argv[1]
        # Also print the command, so this can be used to figure out what it is.
        echo $argv[1]
        return 1
    end
    return 0
end

function __fish_trousseau_using_subcommand
    set -l cmd (__fish_trousseau_needs_command)
    test -z "$cmd"
    and return 1
    contains -- $cmd[1] $argv
end

complete -c trousseau -n "__fish_trousseau_needs_command" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_needs_command" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_needs_command" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_needs_command" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_needs_command" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_needs_command" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_needs_command" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_needs_command" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_needs_command" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_needs_command" -s V -l version -d 'Print version'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "init" -d 'Create a new store'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "info" -d 'Show information about the resolved store'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "set" -d 'Set a key\'s value'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "get" -d 'Get a key\'s value'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "ls" -d 'List keys'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "rm" -d 'Remove one or more keys'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "mv" -d 'Rename a key'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "recipients" -d 'Manage a recipients store\'s recipient list'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "rekey" -d 'Re-encrypt the store, optionally changing its kind or recipients'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "export" -d 'Export the store\'s entries'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "import" -d 'Import entries into the store'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "run" -d 'Run a command with the store\'s entries injected as environment variables'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "env" -d 'Print the store\'s entries as environment variable assignments'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "edit" -d 'Edit the store in `$VISUAL` or `$EDITOR`'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "migrate" -d 'Migrate a legacy v0.4 store into a new store'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "completions" -d 'Print a shell completion script'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "man" -d 'Print a roff man page'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "__clip-clear" -d 'Clear the clipboard after `get --clip` (hidden, internal)'
complete -c trousseau -n "__fish_trousseau_needs_command" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l recipient -d 'A recipient to encrypt to. Repeatable' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l recipients-file -d 'A file of recipients, one per line (blank lines and `#` comments ignored)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l passphrase -d 'Create a passphrase store instead of a recipients store'
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l no-self -d 'Do not add the caller\'s own recipient to a recipients store'
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand init" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand info" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand info" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand info" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand info" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand info" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand info" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand info" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand info" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand info" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l from-file -d 'Read the value from this file. `-` means stdin, verbatim' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l from-env -d 'Read the value from this environment variable' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l env -d 'Override the derived environment variable name' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l description -d 'A free-text description of the entry' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l binary -d 'Force base64 encoding even if the value is valid UTF-8'
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand set" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l out -d 'Write the value to this file instead of stdout' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l force -d 'Overwrite `--out` if it already exists'
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l clip -d 'Copy the value to the clipboard instead of printing it'
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand get" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -l long -d 'Print a table with encoding, env name, update time, and description columns. Never values'
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand ls" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -l force -d 'Ignore keys that do not exist instead of failing'
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand rm" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -l force -d 'Overwrite `new` if it already exists'
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand mv" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -f -a "ls" -d 'List the store\'s recipients'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -f -a "add" -d 'Add one or more recipients'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -f -a "rm" -d 'Remove one or more recipients'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and not __fish_seen_subcommand_from ls add rm help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from ls" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from ls" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from ls" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from ls" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from ls" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from ls" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from ls" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from ls" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from ls" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from add" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from add" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from add" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from add" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from add" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from add" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from add" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from add" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from add" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -l force -d 'Skip the "you removed your own recipient" confirmation'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from rm" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from help" -f -a "ls" -d 'List the store\'s recipients'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from help" -f -a "add" -d 'Add one or more recipients'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from help" -f -a "rm" -d 'Remove one or more recipients'
complete -c trousseau -n "__fish_trousseau_using_subcommand recipients; and __fish_seen_subcommand_from help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l to-recipients -d 'Convert to a recipients store with exactly these recipients' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l to-passphrase -d 'Convert to a passphrase store'
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand rekey" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l format -d 'The output format' -r -f -a "json\t'The full JSON payload document'
dotenv\t'One `NAME="value"` line per UTF-8 entry'
toml\t'The `edit` TOML document format'"
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l out -d 'Write to this file instead of stdout' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l force -d 'Overwrite `--out` if it already exists'
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand export" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l format -d 'The input format' -r -f -a "json\t'The full JSON payload document'
dotenv\t'One `NAME="value"` line per UTF-8 entry'
toml\t'The `edit` TOML document format'"
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l strategy -d 'How to resolve a key that already exists' -r -f -a "keep\t'Keep the existing entry'
overwrite\t'Replace the existing entry with the imported one'
fail\t'Abort the whole import on any collision'"
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand import" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l env-prefix -d 'A prefix prepended to every injected environment variable name. Defaults to `[run].env_prefix` from the configuration file (3.4) when absent' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l only -d 'Only inject entries under this path prefix. Repeatable' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l no-inherit -d 'Give the child only the injected variables plus a small allow list, instead of inheriting the parent\'s environment'
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand run" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l format -d 'The output format. `--json` is an alias for `--format json`' -r -f -a "shell\t'`export NAME=\'value\'` lines'
dotenv\t'`NAME="value"` lines'
json\t'A single `{"NAME": "value"}` JSON object'"
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l env-prefix -d 'A prefix prepended to every environment variable name. Defaults to `[run].env_prefix` from the configuration file (3.4) when absent' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l only -d 'Only include entries under this path prefix. Repeatable' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand env" -s h -l help -d 'Print help (see more with \'--help\')'
complete -c trousseau -n "__fish_trousseau_using_subcommand edit" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand edit" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand edit" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand edit" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand edit" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand edit" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand edit" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand edit" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand edit" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l gpg -d 'The `gpg` binary to use for an `OpenPGP` legacy store' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l gnupg-home -d 'An isolated `GNUPGHOME` to use when invoking `gpg`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l new-passphrase-file -d 'A file holding the new store\'s passphrase (only with `--passphrase`)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l recipient -d 'A recipient to encrypt to. Repeatable' -r
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l recipients-file -d 'A file of recipients, one per line (blank lines and `#` comments ignored)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l passphrase -d 'Create a passphrase store instead of a recipients store'
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l no-self -d 'Do not add the caller\'s own recipient to a recipients store'
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand migrate" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand completions" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand completions" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand completions" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand completions" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand completions" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand completions" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand completions" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand completions" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand completions" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand man" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand man" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand man" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand man" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand man" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand man" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand man" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand man" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand man" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand __clip-clear" -l store -d 'The store to operate on. Overrides every other resolution rule (3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand __clip-clear" -l identity -d 'An identity file to try when unlocking a recipients store. Repeatable (3.3.2)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand __clip-clear" -l identity-file -d 'Hidden, single-value counterpart to `--identity` populated from `TROUSSEAU_IDENTITY_FILE` (3.3.2). Not meant to be typed directly; it exists so the environment variable has a place to land in the parsed arguments. Merged into the identity list by `context.rs`' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand __clip-clear" -l passphrase-file -d 'A file holding the passphrase for a passphrase store (3.3.3)' -r -F
complete -c trousseau -n "__fish_trousseau_using_subcommand __clip-clear" -l global -d 'Use the personal store instead of the nearest project store (3.2)'
complete -c trousseau -n "__fish_trousseau_using_subcommand __clip-clear" -l json -d 'Emit machine-readable JSON instead of human-readable text (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand __clip-clear" -l quiet -d 'Suppress informational stderr lines. Errors still print (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand __clip-clear" -l no-input -d 'Never prompt. Anything that would have prompted fails instead (3.5.1)'
complete -c trousseau -n "__fish_trousseau_using_subcommand __clip-clear" -s h -l help -d 'Print help'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "init" -d 'Create a new store'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "info" -d 'Show information about the resolved store'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "set" -d 'Set a key\'s value'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "get" -d 'Get a key\'s value'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "ls" -d 'List keys'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "rm" -d 'Remove one or more keys'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "mv" -d 'Rename a key'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "recipients" -d 'Manage a recipients store\'s recipient list'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "rekey" -d 'Re-encrypt the store, optionally changing its kind or recipients'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "export" -d 'Export the store\'s entries'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "import" -d 'Import entries into the store'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "run" -d 'Run a command with the store\'s entries injected as environment variables'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "env" -d 'Print the store\'s entries as environment variable assignments'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "edit" -d 'Edit the store in `$VISUAL` or `$EDITOR`'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "migrate" -d 'Migrate a legacy v0.4 store into a new store'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "completions" -d 'Print a shell completion script'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "man" -d 'Print a roff man page'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "__clip-clear" -d 'Clear the clipboard after `get --clip` (hidden, internal)'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and not __fish_seen_subcommand_from init info set get ls rm mv recipients rekey export import run env edit migrate completions man __clip-clear help" -f -a "help" -d 'Print this message or the help of the given subcommand(s)'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and __fish_seen_subcommand_from recipients" -f -a "ls" -d 'List the store\'s recipients'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and __fish_seen_subcommand_from recipients" -f -a "add" -d 'Add one or more recipients'
complete -c trousseau -n "__fish_trousseau_using_subcommand help; and __fish_seen_subcommand_from recipients" -f -a "rm" -d 'Remove one or more recipients'
